package com.pass.dto;

import com.pass.entity.PassStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class PassRequestDTO {

	private int vendorId;
	
	private int customerId;

	private String city;

	private int passLength;

	private PassStatus passStatus;
}
