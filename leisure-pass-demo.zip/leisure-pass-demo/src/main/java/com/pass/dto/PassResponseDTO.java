package com.pass.dto;

import com.pass.entity.PassStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class PassResponseDTO {

	
	private int passId;

	private int vendorId;
	
	private int customerId;

	private String city;

	private int passLength;

	private PassStatus passStatus;
}
