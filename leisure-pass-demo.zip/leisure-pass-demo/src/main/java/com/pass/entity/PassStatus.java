package com.pass.entity;

public enum PassStatus {
	ACTIVE,
	CANCELLED,
	EXPIRED
}
