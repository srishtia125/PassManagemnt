package com.pass.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pass {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int passId;
	
	private int customerId;
	
	private int vendorId;
	
	private String city;
	
	private int passLength;
	
	private PassStatus passStatus;

	/**
	 * @param customerId
	 * @param vendorId
	 * @param cityId
	 * @param passLength
	 * @param passStatus
	 */
	public Pass(int customerId, int vendorId, String city, int passLength, PassStatus passStatus) {
		super();
		this.customerId = customerId;
		this.vendorId = vendorId;
		this.city = city;
		this.passLength = passLength;
		this.passStatus = passStatus;
	}
	

	
	

	/**
	 * 
	 */
	
	
	
}
