package com.pass.service.impl;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pass.dto.PassRequestDTO;
import com.pass.dto.PassResponseDTO;
import com.pass.entity.Customer;
import com.pass.entity.Pass;
import com.pass.entity.PassStatus;
import com.pass.entity.Vendor;
import com.pass.exception.CustomerNotFoundException;
import com.pass.exception.PassCancelledException;
import com.pass.exception.PassNotFoundException;
import com.pass.exception.VendorNotFoundException;
import com.pass.helper.PassDtoHelper;
import com.pass.repository.CustomerRepository;
import com.pass.repository.PassRepository;
import com.pass.repository.VendorRepository;
import com.pass.service.PassService;

@Service
public class PassServiceImpl implements PassService {	

	private PassRepository passRepository;
	
	private VendorRepository vendorRepository;
	
	private CustomerRepository customerRepository;
	
	private static final org.slf4j.Logger logger = LoggerFactory.getLogger(PassService.class);

	/**
	 * @param passRepository
	 * @param vendorRepository
	 */
	@Autowired
	public PassServiceImpl(PassRepository passRepository, VendorRepository vendorRepository,CustomerRepository customerRepository) {
		super();
		this.passRepository = passRepository;
		this.vendorRepository = vendorRepository;
		this.customerRepository = customerRepository;
	}
	
	/**Add a new  pass
	 * @param passRequest
	 * */
	public PassResponseDTO addNewpass(PassRequestDTO passRequest) {
		 logger.info("Saving new pass {}", passRequest);
			Vendor vendor = vendorRepository.findById(passRequest.getVendorId())
					.orElseThrow(() -> new VendorNotFoundException("Vendor with id "+ passRequest.getVendorId()+" does not exist"));
			
			Customer customer = customerRepository.findById(passRequest.getCustomerId())
					.orElseThrow(() -> new CustomerNotFoundException("Customer with id "+ passRequest.getCustomerId()+" does not exist"));
			 
		return PassDtoHelper.convertToPassResponseDTO(passRepository.save(PassDtoHelper.convertToPassEntity(passRequest)));

	}

	/**Validate the pass with the vendor and pass id
	 * @param vendorId
	 * @param passId 
	 * @return Active if exists
	 * */
	public String validate(int vendorId,int passId) {
		 logger.info("Finding vendor {}", vendorId);
		Vendor vendor = vendorRepository.findById(vendorId)
				.orElseThrow(() -> new VendorNotFoundException("Vendor with id "+ vendorId+" does not exist"));
		 
		logger.info("Finding pass {}", passId);
		Pass pass = passRepository.findById(passId)
				.orElseThrow(() -> new PassNotFoundException("Pass with id "+ passId+" does not exist"));
		
		if(vendor.getVendorId() == pass.getVendorId()) {
			if (!PassStatus.ACTIVE.equals(pass.getPassStatus())) {
				return "Invalid: pass status is  "+pass.getPassStatus();
			}
		}	else {
			return "Invalid: Vendor for pass ID "+pass.getPassId();
		}	
		return PassStatus.ACTIVE.toString();
	}

	public PassResponseDTO renewPass(int passId) throws PassCancelledException {
		logger.info("Renew existing pass {}", passId);
        // find an existing  pass to update
		Pass pass = passRepository.findById(passId)
				.orElseThrow(() -> new PassNotFoundException("Pass with id "+ passId +" does not exist"));
		
		if(PassStatus.CANCELLED.equals(pass.getPassStatus())){
			
			throw new PassCancelledException("Pass with id "+ passId +" is cancelled");
			
		}else {
			pass.setPassStatus(PassStatus.ACTIVE);
		}
		return PassDtoHelper
				.convertToPassResponseDTO(passRepository.save(pass));
	}

	public PassResponseDTO cancelPass(int passId) throws PassCancelledException {
		logger.info("Cancel existing pass {}", passId);
		Pass existingPass = passRepository.findById(passId)
				.orElseThrow(() -> new PassNotFoundException("Pass with id "+ passId +" does not exist"));
		
		if(PassStatus.CANCELLED.equals(existingPass.getPassStatus())){	
				throw new PassCancelledException("Pass with id "+ passId +" is already cancelled");		
		}
		existingPass.setPassStatus(PassStatus.CANCELLED);
		return PassDtoHelper
				.convertToPassResponseDTO(passRepository.save(existingPass));
	}

	@Override
	public PassResponseDTO getPass(int passId) {
		 
			logger.info("Finding pass {}", passId);
			Pass pass = passRepository.findById(passId)
					.orElseThrow(() -> new PassNotFoundException("Pass with id "+ passId+" does not exist"));
			return PassDtoHelper
					.convertToPassResponseDTO(pass);
	}

}
