package com.pass.service;

import com.pass.dto.PassRequestDTO;
import com.pass.dto.PassResponseDTO;
import com.pass.exception.PassCancelledException;

public interface PassService {

	PassResponseDTO addNewpass(PassRequestDTO passRequest);

	String validate(int vendorId,int passId);

	PassResponseDTO renewPass(int passId) throws PassCancelledException;

	PassResponseDTO cancelPass(int passId) throws PassCancelledException;
	
	PassResponseDTO getPass(int passId);

}
