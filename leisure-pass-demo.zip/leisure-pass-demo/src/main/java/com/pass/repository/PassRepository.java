package com.pass.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pass.entity.Pass;

@Repository
public interface PassRepository extends CrudRepository<Pass, Integer> {}