package com.pass.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pass.entity.Pass;
import com.pass.entity.Vendor;

@Repository
public interface VendorRepository  extends CrudRepository<Vendor, Integer> {}