package com.pass.exception;


public class PassCancelledException extends Exception {

	public PassCancelledException(String message) {
		super(message);
	}

}
