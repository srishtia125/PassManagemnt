package com.pass.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class PassExceptionHandler {

    @ExceptionHandler({PassNotFoundException.class})
    public ResponseEntity<ErrorData> handlePassNotFoundException(Exception ex) {
        return getErrorData(ex, HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler({VendorNotFoundException.class})
    public ResponseEntity<ErrorData> handleVendorNotFoundException(Exception ex) {
        return getErrorData(ex, HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler({CustomerNotFoundException.class})
    public ResponseEntity<ErrorData> handleCustomerNotFoundException(Exception ex) {
        return getErrorData(ex, HttpStatus.NOT_FOUND);
    }
    
    
    @ExceptionHandler({PassCancelledException.class})
    public ResponseEntity<ErrorData> handlePassCanclledtFoundException(Exception ex) {
        return getErrorData(ex, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    private ResponseEntity<ErrorData> getErrorData(Exception ex, HttpStatus status){
    	  	      
    	        ErrorData response = new ErrorData();
    	        response.setErrorMessage(ex.getMessage());
    	        response.setstatus(status);
    	        return new ResponseEntity<ErrorData>(response,status);
    	    }
    

}

