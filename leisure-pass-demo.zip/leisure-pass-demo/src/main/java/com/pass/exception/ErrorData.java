package com.pass.exception;

import org.springframework.http.HttpStatus;

public class ErrorData {

    private HttpStatus status;
    private String errorMessage;

    public HttpStatus getstatus() {
        return status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setstatus(HttpStatus notFound) {
        this.status = notFound;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}