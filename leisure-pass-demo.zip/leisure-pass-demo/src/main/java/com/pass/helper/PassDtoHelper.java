package com.pass.helper;

import com.pass.dto.PassRequestDTO;
import com.pass.dto.PassResponseDTO;
import com.pass.entity.Pass;

/**
 * Helper class to convert entity to DTO and viceversa
 */

public class PassDtoHelper {

	public static Pass convertToPassEntity(PassRequestDTO passRequestDTO) {

		return new Pass(passRequestDTO.getCustomerId(), passRequestDTO.getVendorId(), passRequestDTO.getCity(),
				passRequestDTO.getPassLength(), passRequestDTO.getPassStatus());

	}

	public static PassResponseDTO convertToPassResponseDTO(Pass pass) {

		return new PassResponseDTO(pass.getPassId(), pass.getVendorId(), pass.getCustomerId(), pass.getCity(),
				pass.getPassLength(), pass.getPassStatus());

	}

}
