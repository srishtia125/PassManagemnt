package com.pass.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pass.dto.PassRequestDTO;
import com.pass.dto.PassResponseDTO;
import com.pass.exception.PassCancelledException;
import com.pass.service.PassService;

import io.swagger.annotations.ApiOperation;

@RestController
public class PassController {

	@Autowired
	private PassService passService;


	@PostMapping("/pass")
	@ApiOperation(value = "To add new pass")
	@ResponseStatus(code = HttpStatus.CREATED)
	public PassResponseDTO addpass(@RequestBody PassRequestDTO passRequest) {
		return passService.addNewpass(passRequest);
	}
	
	@GetMapping("/validate")
	@ApiOperation(value = "To validate pass with customer id")
	@ResponseStatus(code = HttpStatus.OK)
	public  String validatePass(@RequestParam int vendorId,@RequestParam int passId) {
		return passService.validate(vendorId,passId);
	}
	
	@PutMapping("/renew/{passId}")
	@ApiOperation(value = "To reneew pass ")
	@ResponseStatus(code = HttpStatus.OK)
	public  PassResponseDTO renewPass(@PathVariable int passId) throws PassCancelledException {
		return passService.renewPass(passId);
	}
	
	@PutMapping(value = "/cancel/{passId}")
	@ApiOperation(value = "To cancel an exising pass ")
	@ResponseStatus(code = HttpStatus.ACCEPTED)
    public PassResponseDTO cancelPass(@PathVariable int passId) throws PassCancelledException {
       return passService.cancelPass(passId);
        
    }
}
