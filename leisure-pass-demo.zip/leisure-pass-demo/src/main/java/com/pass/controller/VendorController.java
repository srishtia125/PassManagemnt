package com.pass.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pass.dto.PassRequestDTO;
import com.pass.dto.PassResponseDTO;
import com.pass.entity.Vendor;
import com.pass.repository.VendorRepository;

import io.swagger.annotations.ApiOperation;


@RestController
public class VendorController {
	
	@Autowired
	private VendorRepository vendorRepository;

	@PostMapping("/vendor")
	@ApiOperation(value = "To add new vendor")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Vendor addVendor(@RequestBody Vendor vendor) {
		return vendorRepository.save(vendor);
	}
	
	
	
}
