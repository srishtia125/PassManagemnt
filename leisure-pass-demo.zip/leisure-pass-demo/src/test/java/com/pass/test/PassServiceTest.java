package com.pass.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.pass.config.Application;
import com.pass.dto.PassRequestDTO;
import com.pass.dto.PassResponseDTO;
import com.pass.entity.PassStatus;
import com.pass.exception.PassCancelledException;
import com.pass.exception.PassNotFoundException;
import com.pass.exception.VendorNotFoundException;
import com.pass.repository.CustomerRepository;
import com.pass.repository.PassRepository;
import com.pass.repository.VendorRepository;
import com.pass.service.PassService;
import com.pass.service.impl.PassServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class PassServiceTest {

	private PassService passService;

	@Autowired
	private PassRepository passRepository;

	@Autowired
	private VendorRepository vendorRepository;
	
	@Autowired
	private CustomerRepository customerRepository;

		
	@Before
	public void setup() {
		passService = new PassServiceImpl(passRepository,vendorRepository,customerRepository);
	}
	
	@Test
	public void addNewPassTest() throws PassCancelledException {
		PassRequestDTO pass = new PassRequestDTO(10, 1, "Test1", 1, PassStatus.ACTIVE);
		PassResponseDTO newPass = passService.addNewpass(pass);		
		
		  assertEquals(1,newPass.getPassId());
		  assertEquals(PassStatus.ACTIVE,newPass.getPassStatus());
	}
	
	/***
	 * 1. Validate pass is saved in database with correct details
	 * @throws PassCancelledException 
	 */
	@Test
	public void renewPassForNonExistingPassIdTest() throws PassCancelledException {
		int invalidPassId = 900;
		PassNotFoundException ex =  assertThrows(
	                PassNotFoundException.class,
	                () -> { passService.renewPass(invalidPassId); }
	        );
	        assertEquals("Pass with id " +invalidPassId + " does not exist", ex.getMessage());
	}
	
	@Test
	public void renewPassForCancelledPassIdTest() throws PassCancelledException {
		PassRequestDTO pass = new PassRequestDTO(10, 1,  "Test2", 1, PassStatus.CANCELLED);
				
		PassResponseDTO cancelledPass = passService.addNewpass(pass);
		PassCancelledException ex =  assertThrows(
				PassCancelledException.class,
	                () -> { passService.renewPass(cancelledPass.getPassId()); }
	        );
	        assertEquals("Pass with id " +cancelledPass.getPassId() + " is cancelled", ex.getMessage());
	}

	@Test
	public void renewPassForExistingPassIdTest() throws PassCancelledException {
		PassRequestDTO pass = new PassRequestDTO(10, 1, "Test3",1, PassStatus.EXPIRED);
		
		PassResponseDTO expiredPass = passService.addNewpass(pass);
		PassResponseDTO renewdPass = passService.renewPass(expiredPass.getPassId());
				
		assertEquals(PassStatus.ACTIVE,renewdPass.getPassStatus());
	}

	@Test
	public void cancelPassForExistingPassIdTest() throws PassCancelledException {
		PassRequestDTO pass = new PassRequestDTO(10, 1,"Test4", 1, PassStatus.EXPIRED);
		
		PassResponseDTO existingPass = passService.addNewpass(pass);
		PassResponseDTO cancelledPass = passService.cancelPass(existingPass.getPassId());
				
		assertEquals(PassStatus.CANCELLED,cancelledPass.getPassStatus());
	}
	
	@Test
	public void cancelPassForCancelledPassIdTest() throws PassCancelledException {
		
		PassRequestDTO pass = new PassRequestDTO(10, 1, "Test5",1, PassStatus.CANCELLED);
		PassResponseDTO cancelledPass = passService.addNewpass(pass);
		PassCancelledException ex =  assertThrows(
				PassCancelledException.class,
	                () -> { passService.cancelPass(cancelledPass.getPassId()); }
	        );
	        assertEquals("Pass with id " +cancelledPass.getPassId() + " is already cancelled", ex.getMessage());
	}
	
	@Test
	public void validatePassForInvalidVendorIdTest() throws PassCancelledException {
		int invalidVendorId = 10;
		PassRequestDTO pass = new PassRequestDTO(10, 1, "Test6",1, PassStatus.ACTIVE);
		PassResponseDTO validPass = passService.addNewpass(pass);
		VendorNotFoundException ex =  assertThrows(
				VendorNotFoundException.class,
	                () -> { passService.validate(invalidVendorId, validPass.getPassId()); }
	        );
	        assertEquals("Vendor with id "+ invalidVendorId+" does not exist", ex.getMessage());
	}
	
	



}
